import base


t = base.df_receipt.head(10)
print(t)
